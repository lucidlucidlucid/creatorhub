A free to use font based on insects. 
Share with me if you use it! I would love to see its application.

https://www.behance.net/170018adob8cb8

http://instagram.com/elby.creative